package com.example.demo.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Details;
import com.example.demo.entity.Engineer;

@Repository
public interface EngineerRepository extends JpaRepository<Engineer, Long>
{
	@Query("select e from Engineer e where e.address like %:city%")
	List<Engineer> findEngineersByCity(@Param("city")String city);
	
	@Query("select e.engineerId, e.address from Engineer e where e.engineerId=:eid")
	Details findDetails(@Param("eid") Long engineerId);
}
