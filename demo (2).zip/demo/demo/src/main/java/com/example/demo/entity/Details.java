package com.example.demo.entity;

public class Details {
	Long engineerId=0L;
	String address="";
	public Details() {}
	public Details(Long engineerId, String address) {
		super();
		this.engineerId = engineerId;
		this.address = address;
	}
	public Long getEngineerId() {
		return engineerId;
	}
	public void setEngineerId(Long engineerId) {
		this.engineerId = engineerId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
